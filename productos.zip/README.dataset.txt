# My First Project > 2025-04-07 5:28pm
https://universe.roboflow.com/productdetection-qf4rf/my-first-project-3rgrw

Provided by a Roboflow user
License: CC BY 4.0

